/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./AttributeCollectionSelector/AttributeCollectionSelectorComponent.tsx"
/*!******************************************************************************!*\
  !*** ./AttributeCollectionSelector/AttributeCollectionSelectorComponent.tsx ***!
  \******************************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   AttributeCollectionSelectorComponent: () => (/* binding */ AttributeCollectionSelectorComponent)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\n\nvar dropdownStyles = {\n  width: '100%',\n  minWidth: '200px'\n};\nvar dropdownContainerStyles = {\n  display: 'flex',\n  flexDirection: 'column',\n  width: '100%'\n};\nvar listboxStyles = {\n  maxHeight: '300px',\n  overflow: 'auto',\n  backgroundColor: '#ffffff',\n  border: '1px solid #e0e0e0',\n  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',\n  padding: '4px 0'\n};\nvar optionStyles = {\n  padding: '10px 12px',\n  lineHeight: '1.6'\n};\nvar AttributeCollectionSelectorComponent = props => {\n  var [attributes, setAttributes] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [selectedOptions, setSelectedOptions] = react__WEBPACK_IMPORTED_MODULE_0__.useState(props.selectedAttributes || []);\n  var [selectedDisplayText, setSelectedDisplayText] = react__WEBPACK_IMPORTED_MODULE_0__.useState('');\n  var [loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  var getAttributes = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(entityName => __awaiter(void 0, void 0, void 0, function* () {\n    var _a, _b, _c, _d;\n    try {\n      if (!entityName) {\n        console.warn('AttributeCollectionSelector: No entity name provided');\n        return [];\n      }\n      var baseUrl = ((_d = (_c = (_b = (_a = window.Xrm) === null || _a === void 0 ? void 0 : _a.Page) === null || _b === void 0 ? void 0 : _b.context) === null || _c === void 0 ? void 0 : _c.getClientUrl) === null || _d === void 0 ? void 0 : _d.call(_c)) || '';\n      if (!baseUrl) {\n        console.warn('Could not retrieve base URL from Xrm.Page');\n        return [];\n      }\n      console.log('AttributeCollectionSelector: Fetching attributes for entity:', entityName);\n      var response = yield fetch(\"\".concat(baseUrl, \"/api/data/v9.1/EntityDefinitions(LogicalName='\").concat(entityName, \"')/Attributes?$select=LogicalName,DisplayName,AttributeType\"), {\n        method: 'GET',\n        headers: {\n          'OData-MaxVersion': '4.0',\n          'OData-Version': '4.0',\n          'Accept': 'application/json',\n          'Content-Type': 'application/json; charset=utf-8'\n        }\n      });\n      if (!response.ok) {\n        throw new Error(\"HTTP error! status: \".concat(response.status));\n      }\n      var result = yield response.json();\n      var attributeOptions = [];\n      console.log('AttributeCollectionSelector: API response:', result);\n      if (result.value && Array.isArray(result.value)) {\n        result.value.forEach(attr => {\n          var _a, _b;\n          if ((_b = (_a = attr.DisplayName) === null || _a === void 0 ? void 0 : _a.UserLocalizedLabel) === null || _b === void 0 ? void 0 : _b.Label) {\n            attributeOptions.push({\n              key: attr.LogicalName,\n              text: attr.DisplayName.UserLocalizedLabel.Label\n            });\n          }\n        });\n      }\n      // Sort alphabetically by text\n      attributeOptions.sort((a, b) => a.text.localeCompare(b.text));\n      console.log('AttributeCollectionSelector: Found', attributeOptions.length, 'attributes');\n      return attributeOptions;\n    } catch (error) {\n      console.error('Error retrieving attributes:', error);\n      return [];\n    }\n  }), []);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    setLoading(true);\n    getAttributes(props.entityName).then(result => {\n      setAttributes(result);\n      setLoading(false);\n    });\n  }, [props.entityName, getAttributes]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (props.selectedAttributes && attributes.length > 0) {\n      var displayTexts = props.selectedAttributes.map(key => {\n        var attr = attributes.find(a => a.key === key);\n        return attr ? \"\".concat(attr.text, \" (\").concat(attr.key, \")\") : '';\n      }).filter(text => text !== '');\n      setSelectedDisplayText(displayTexts.join(', '));\n    } else {\n      setSelectedDisplayText('');\n    }\n  }, [props.selectedAttributes, attributes]);\n  var handleSelectionChange = (event, data) => {\n    var selected = data.selectedOptions;\n    setSelectedOptions(selected);\n    var displayTexts = selected.map(key => {\n      var attr = attributes.find(a => a.key === key);\n      return attr ? \"\".concat(attr.text, \" (\").concat(attr.key, \")\") : '';\n    }).filter(text => text !== '');\n    setSelectedDisplayText(displayTexts.join(', '));\n    props.onChange(selected);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: dropdownContainerStyles\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {\n    style: dropdownStyles,\n    multiselect: true,\n    placeholder: loading ? \"Loading attributes...\" : \"Select attributes\",\n    value: selectedDisplayText,\n    selectedOptions: selectedOptions,\n    onOptionSelect: handleSelectionChange,\n    disabled: props.disabled || loading,\n    listbox: {\n      style: listboxStyles\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: \"\",\n    value: \"\",\n    text: \"\",\n    style: optionStyles\n  }), attributes.map(attr => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: attr.key,\n    value: attr.key,\n    text: \"\".concat(attr.text, \" (\").concat(attr.key, \")\"),\n    style: optionStyles\n  }, attr.text, \" (\", attr.key, \")\")))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AttributeCollectionSelector/AttributeCollectionSelectorComponent.tsx?\n}");

/***/ },

/***/ "./AttributeCollectionSelector/index.ts"
/*!**********************************************!*\
  !*** ./AttributeCollectionSelector/index.ts ***!
  \**********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   AttributeCollectionSelector: () => (/* binding */ AttributeCollectionSelector)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _AttributeCollectionSelectorComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AttributeCollectionSelectorComponent */ \"./AttributeCollectionSelector/AttributeCollectionSelectorComponent.tsx\");\n\n\nclass AttributeCollectionSelector {\n  constructor() {}\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.context = context;\n    this.selectedAttributes = this.parseAttributeString(context.parameters.Attribute.raw || \"\");\n  }\n  updateView(context) {\n    this.context = context;\n    var props = {\n      selectedAttributes: this.parseAttributeString(context.parameters.Attribute.raw || \"\"),\n      entityName: context.parameters.EntityName.raw || \"\",\n      disabled: context.mode.isControlDisabled,\n      onChange: this.onChange.bind(this)\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_AttributeCollectionSelectorComponent__WEBPACK_IMPORTED_MODULE_1__.AttributeCollectionSelectorComponent, props);\n  }\n  getOutputs() {\n    return {\n      Attribute: this.selectedAttributes.join(\";\")\n    };\n  }\n  destroy() {\n    // Cleanup if needed\n  }\n  onChange(selectedAttributes) {\n    this.selectedAttributes = selectedAttributes;\n    this.notifyOutputChanged();\n  }\n  parseAttributeString(attributeString) {\n    return attributeString ? attributeString.split(\";\").filter(a => a.trim()) : [];\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./AttributeCollectionSelector/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./AttributeCollectionSelector/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('mdt.AttributeCollectionSelector', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AttributeCollectionSelector);
} else {
	var mdt = mdt || {};
	mdt.AttributeCollectionSelector = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.AttributeCollectionSelector;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}