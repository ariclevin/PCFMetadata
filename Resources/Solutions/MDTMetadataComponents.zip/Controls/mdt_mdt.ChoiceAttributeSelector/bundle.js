/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ChoiceAttributeSelector/ChoiceAttributeSelectorComponent.tsx"
/*!**********************************************************************!*\
  !*** ./ChoiceAttributeSelector/ChoiceAttributeSelectorComponent.tsx ***!
  \**********************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ChoiceAttributeSelectorComponent: () => (/* binding */ ChoiceAttributeSelectorComponent)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\n\nvar dropdownStyles = {\n  width: '100%',\n  minWidth: '200px'\n};\nvar dropdownContainerStyles = {\n  display: 'flex',\n  flexDirection: 'column',\n  width: '100%'\n};\nvar listboxStyles = {\n  maxHeight: '300px',\n  overflow: 'auto',\n  backgroundColor: '#ffffff',\n  border: '1px solid #e0e0e0',\n  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',\n  padding: '4px 0'\n};\nvar optionStyles = {\n  padding: '10px 12px',\n  lineHeight: '1.6'\n};\nvar ChoiceAttributeSelectorComponent = props => {\n  var [choiceAttributes, setChoiceAttributes] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [selectedOption, setSelectedOption] = react__WEBPACK_IMPORTED_MODULE_0__.useState(props.selectedAttribute || '');\n  var [selectedDisplayText, setSelectedDisplayText] = react__WEBPACK_IMPORTED_MODULE_0__.useState('');\n  var [loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  var getChoiceAttributes = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(entityName => __awaiter(void 0, void 0, void 0, function* () {\n    var _a, _b, _c, _d;\n    try {\n      if (!entityName) return [];\n      var baseUrl = ((_d = (_c = (_b = (_a = window.Xrm) === null || _a === void 0 ? void 0 : _a.Page) === null || _b === void 0 ? void 0 : _b.context) === null || _c === void 0 ? void 0 : _c.getClientUrl) === null || _d === void 0 ? void 0 : _d.call(_c)) || '';\n      if (!baseUrl) {\n        console.warn('Could not retrieve base URL from Xrm.Page');\n        return [];\n      }\n      var response = yield fetch(\"\".concat(baseUrl, \"/api/data/v9.1/EntityDefinitions(LogicalName='\").concat(entityName, \"')/Attributes?$select=LogicalName,DisplayName,AttributeType&$filter=AttributeType eq 'Picklist' or AttributeType eq 'Status' or AttributeType eq 'State'\"), {\n        method: 'GET',\n        headers: {\n          'OData-MaxVersion': '4.0',\n          'OData-Version': '4.0',\n          'Accept': 'application/json',\n          'Content-Type': 'application/json; charset=utf-8'\n        }\n      });\n      if (!response.ok) {\n        throw new Error(\"HTTP error! status: \".concat(response.status));\n      }\n      var result = yield response.json();\n      var _choiceAttributes = [];\n      if (result.value && Array.isArray(result.value)) {\n        result.value.forEach(optionSet => {\n          var _a, _b;\n          if ((_b = (_a = optionSet.DisplayName) === null || _a === void 0 ? void 0 : _a.UserLocalizedLabel) === null || _b === void 0 ? void 0 : _b.Label) {\n            _choiceAttributes.push({\n              key: optionSet.LogicalName,\n              text: optionSet.DisplayName.UserLocalizedLabel.Label\n            });\n          }\n        });\n      }\n      // Sort alphabetically by text\n      _choiceAttributes.sort((a, b) => a.text.localeCompare(b.text));\n      return _choiceAttributes;\n    } catch (error) {\n      console.error('Error retrieving option sets:', error);\n      return [];\n    }\n  }), []);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    setLoading(true);\n    getChoiceAttributes(props.entity).then(result => {\n      setChoiceAttributes(result);\n      setLoading(false);\n    });\n  }, [props.entity, getChoiceAttributes]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (props.selectedAttribute && choiceAttributes.length > 0) {\n      var choice = choiceAttributes.find(c => c.key === props.selectedAttribute);\n      if (choice) {\n        setSelectedDisplayText(\"\".concat(choice.text, \" (\").concat(choice.key, \")\"));\n      }\n    }\n  }, [props.selectedAttribute, choiceAttributes]);\n  var handleSelectionChange = (event, data) => {\n    var selected = data.optionValue || '';\n    setSelectedOption(selected);\n    var choice = choiceAttributes.find(c => c.key === selected);\n    if (choice) {\n      setSelectedDisplayText(\"\".concat(choice.text, \" (\").concat(choice.key, \")\"));\n    }\n    props.onChange(selected);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: dropdownContainerStyles\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {\n    style: dropdownStyles,\n    placeholder: loading ? \"Loading choices...\" : \"Select choice\",\n    value: selectedDisplayText,\n    selectedOptions: [selectedOption],\n    onOptionSelect: handleSelectionChange,\n    disabled: props.disabled || loading,\n    listbox: {\n      style: listboxStyles\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: \"\",\n    value: \"\",\n    text: \"\",\n    style: optionStyles\n  }), choiceAttributes.map(choiceAttribute => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: choiceAttribute.key,\n    value: choiceAttribute.key,\n    text: \"\".concat(choiceAttribute.text, \" (\").concat(choiceAttribute.key, \")\"),\n    style: optionStyles\n  }, choiceAttribute.text, \" (\", choiceAttribute.key, \")\")))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoiceAttributeSelector/ChoiceAttributeSelectorComponent.tsx?\n}");

/***/ },

/***/ "./ChoiceAttributeSelector/index.ts"
/*!******************************************!*\
  !*** ./ChoiceAttributeSelector/index.ts ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ChoiceAttributeSelector: () => (/* binding */ ChoiceAttributeSelector)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _ChoiceAttributeSelectorComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ChoiceAttributeSelectorComponent */ \"./ChoiceAttributeSelector/ChoiceAttributeSelectorComponent.tsx\");\n\n\nclass ChoiceAttributeSelector {\n  constructor() {}\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.context = context;\n    this.currentOptionSet = context.parameters.Attribute.raw || \"\";\n  }\n  updateView(context) {\n    this.context = context;\n    var props = {\n      selectedAttribute: context.parameters.Attribute.raw || \"\",\n      entity: context.parameters.Entity.raw || \"\",\n      disabled: context.mode.isControlDisabled,\n      onChange: this.onChange.bind(this)\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ChoiceAttributeSelectorComponent__WEBPACK_IMPORTED_MODULE_1__.ChoiceAttributeSelectorComponent, props);\n  }\n  getOutputs() {\n    return {\n      Attribute: this.currentOptionSet\n    };\n  }\n  destroy() {\n    // Cleanup if needed\n  }\n  onChange(selectedOptionSet) {\n    this.currentOptionSet = selectedOptionSet;\n    this.notifyOutputChanged();\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoiceAttributeSelector/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ChoiceAttributeSelector/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('mdt.ChoiceAttributeSelector', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoiceAttributeSelector);
} else {
	var mdt = mdt || {};
	mdt.ChoiceAttributeSelector = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoiceAttributeSelector;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}