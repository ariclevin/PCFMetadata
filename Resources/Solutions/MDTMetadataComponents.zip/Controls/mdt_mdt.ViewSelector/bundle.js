/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ViewSelector/ViewSelectorComponent.tsx"
/*!************************************************!*\
  !*** ./ViewSelector/ViewSelectorComponent.tsx ***!
  \************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ViewSelectorComponent: () => (/* binding */ ViewSelectorComponent)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react-components */ \"@fluentui/react-components\");\n/* harmony import */ var _fluentui_react_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__);\nvar __awaiter = undefined && undefined.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\n\nvar dropdownStyles = {\n  width: '100%',\n  minWidth: '200px'\n};\nvar dropdownContainerStyles = {\n  display: 'flex',\n  flexDirection: 'column',\n  width: '100%'\n};\nvar listboxStyles = {\n  maxHeight: '300px',\n  overflow: 'auto',\n  backgroundColor: '#ffffff',\n  border: '1px solid #e0e0e0',\n  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',\n  padding: '4px 0'\n};\nvar optionStyles = {\n  padding: '10px 12px',\n  lineHeight: '1.6'\n};\nvar ViewSelectorComponent = props => {\n  var [views, setViews] = react__WEBPACK_IMPORTED_MODULE_0__.useState([]);\n  var [selectedOption, setSelectedOption] = react__WEBPACK_IMPORTED_MODULE_0__.useState(props.selectedView || '');\n  var [selectedDisplayText, setSelectedDisplayText] = react__WEBPACK_IMPORTED_MODULE_0__.useState('');\n  var [loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_0__.useState(false);\n  var getViews = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(entityName => __awaiter(void 0, void 0, void 0, function* () {\n    var _a, _b, _c, _d;\n    try {\n      if (!entityName) return [];\n      var baseUrl = ((_d = (_c = (_b = (_a = window.Xrm) === null || _a === void 0 ? void 0 : _a.Page) === null || _b === void 0 ? void 0 : _b.context) === null || _c === void 0 ? void 0 : _c.getClientUrl) === null || _d === void 0 ? void 0 : _d.call(_c)) || '';\n      if (!baseUrl) {\n        console.warn('Could not retrieve base URL from Xrm.Page');\n        return [];\n      }\n      var response = yield fetch(\"\".concat(baseUrl, \"/api/data/v9.1/savedqueries?$select=savedqueryid,name,returnedtypecode&$filter=returnedtypecode eq '\").concat(entityName, \"'\"), {\n        method: 'GET',\n        headers: {\n          'OData-MaxVersion': '4.0',\n          'OData-Version': '4.0',\n          'Accept': 'application/json',\n          'Content-Type': 'application/json; charset=utf-8'\n        }\n      });\n      if (!response.ok) {\n        throw new Error(\"HTTP error! status: \".concat(response.status));\n      }\n      var result = yield response.json();\n      var viewOptions = [];\n      if (result.value && Array.isArray(result.value)) {\n        result.value.forEach(view => {\n          if (view.name) {\n            viewOptions.push({\n              key: view.savedqueryid,\n              text: view.name\n            });\n          }\n        });\n      }\n      // Sort alphabetically by text\n      viewOptions.sort((a, b) => a.text.localeCompare(b.text));\n      return viewOptions;\n    } catch (error) {\n      console.error('Error retrieving views:', error);\n      return [];\n    }\n  }), []);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    setLoading(true);\n    getViews(props.entity).then(result => {\n      setViews(result);\n      setLoading(false);\n    });\n  }, [props.entity, getViews]);\n  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(() => {\n    if (props.selectedView && views.length > 0) {\n      var view = views.find(v => v.key === props.selectedView);\n      if (view) {\n        setSelectedDisplayText(\"\".concat(view.text, \" (\").concat(view.key, \")\"));\n      }\n    }\n  }, [props.selectedView, views]);\n  var handleSelectionChange = (event, data) => {\n    var selected = data.optionValue || '';\n    setSelectedOption(selected);\n    var view = views.find(v => v.key === selected);\n    if (view) {\n      setSelectedDisplayText(\"\".concat(view.text, \" (\").concat(view.key, \")\"));\n    }\n    props.onChange(selected);\n  };\n  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n    style: dropdownContainerStyles\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Dropdown, {\n    style: dropdownStyles,\n    placeholder: loading ? \"Loading views...\" : \"Select view\",\n    value: selectedDisplayText,\n    selectedOptions: [selectedOption],\n    onOptionSelect: handleSelectionChange,\n    disabled: props.disabled || loading,\n    listbox: {\n      style: listboxStyles\n    }\n  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: \"\",\n    value: \"\",\n    text: \"\",\n    style: optionStyles\n  }), views.map(view => (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react_components__WEBPACK_IMPORTED_MODULE_1__.Option, {\n    key: view.key,\n    value: view.key,\n    text: \"\".concat(view.text, \" (\").concat(view.key, \")\"),\n    style: optionStyles\n  }, view.text, \" (\", view.key, \")\")))));\n};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ViewSelector/ViewSelectorComponent.tsx?\n}");

/***/ },

/***/ "./ViewSelector/index.ts"
/*!*******************************!*\
  !*** ./ViewSelector/index.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ViewSelector: () => (/* binding */ ViewSelector)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _ViewSelectorComponent__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ViewSelectorComponent */ \"./ViewSelector/ViewSelectorComponent.tsx\");\n\n\nclass ViewSelector {\n  constructor() {}\n  init(context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.context = context;\n    this.currentView = context.parameters.View.raw || \"\";\n  }\n  updateView(context) {\n    this.context = context;\n    var props = {\n      selectedView: context.parameters.View.raw || \"\",\n      entity: context.parameters.Entity.raw || \"\",\n      disabled: context.mode.isControlDisabled,\n      onChange: this.onChange.bind(this)\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ViewSelectorComponent__WEBPACK_IMPORTED_MODULE_1__.ViewSelectorComponent, props);\n  }\n  getOutputs() {\n    return {\n      View: this.currentView\n    };\n  }\n  destroy() {\n    // Cleanup if needed\n  }\n  onChange(selectedView) {\n    this.currentView = selectedView;\n    this.notifyOutputChanged();\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ViewSelector/index.ts?\n}");

/***/ },

/***/ "@fluentui/react-components"
/*!************************************!*\
  !*** external "FluentUIReactv940" ***!
  \************************************/
(module) {

module.exports = FluentUIReactv940;

/***/ },

/***/ "react"
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
(module) {

module.exports = Reactv16;

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Check if module exists (development only)
/******/ 		if (__webpack_modules__[moduleId] === undefined) {
/******/ 			var e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ViewSelector/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('mdt.ViewSelector', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ViewSelector);
} else {
	var mdt = mdt || {};
	mdt.ViewSelector = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ViewSelector;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}